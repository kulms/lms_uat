<html>
<head>
<title>Company List</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>

<body bgcolor="#FFFFFF">
<font face="AngsanaUPC">

<?
  print ("<table width=\"75%\" border=\"1\"><tr><td>�ӴѺ</td><td>���ͺ���ѷ</td><td>��������áԨ</td><td>ʶҹ�����</td>");
    $count=0;
    require("sql_password.php");
    $link = mysql_connect($server,$sql_username,$sql_password);
    $select = mysql_select_db("ieprojectdatabase",$link);
    $query = "select * from company";
    $result = mysql_query($query,$link);
    while ($row = mysql_fetch_row($result))
    {
      $count=$count+1;
      print ("
      <tr>
      <td>$count</td>
      <td>$row[1]</td>
      <td>$row[2]</td>
      <td>$row[3]</td>
      </tr>");
    }  
  print ("</table>");
?>

</font>
</body>
</html>