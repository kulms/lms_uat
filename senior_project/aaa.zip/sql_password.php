<?
$server="localhost";
$sql_username="ponkub";
$sql_password="ponkub0317";
?>