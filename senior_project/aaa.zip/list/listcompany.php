<html>
<head>
<title>Company List</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>

<body bgcolor="#99FFFF">
<font face="MS San Sarif">
<center><img src = kaset_small.jpg><img src = company_search.jpg><img src = kaset_small.jpg></center>
<br>
<center><img src = newline.jpg></center>
<br>
<?
  require("../sql_password.php");
  $link = mysql_connect($server,$sql_username,$sql_password);
  $select = mysql_select_db("ieprojectdatabase",$link);
  $query = "select * from company";
  $result = mysql_query($query,$link);
  print 
  ("
    <table width=\"75%\" border=\"1\" align = center>
    <tr>
      <td><p align=center><b>�ӴѺ</b></p></td>
      <td><p align=center><b>���ͺ���ѷ</b></p></td>
      <td><p align=center><b>��������áԨ</b></p></td>
      <td><p align=center><b>ʶҹ�����</b></p></td>
      <td><p align=center><b>�������Ѿ��</b></p></td>
    </tr>
  ");
  $count=0;
  while ($row = mysql_fetch_row($result))
  {
    $count=$count+1;
    print 
    ("
      <tr>
        <td><p align=center>$count</p></td>
        <td><a href=search.php?company_id=$row[0]&list=company>$row[1]</a></td>
        <td>$row[2]</td>
        <td>$row[3]</td>
        <td><p align=center>$row[4]</p></td> 
     </tr>
    ");
  }  
  print ("</table>");
?>

</font>
<br>
<center><img src = line.jpg></center>
<br>
<center><font size = 0 color = orange face="MS San Sarif"><a href = list.html>���ҵ��</a></font></center>
<center>
<font color = orange size = 0 face="MS San Sarif">
<a href = listproject.php>�����ç�ҹ</a>
<a href = liststudent.php>���͹ѡ�֡��</a>
<a href = listadviser.php>�����Ҩ����</a>
<a href = listsubject.php>�����Ԫ�</a>
<a href = listcompany.php>���ͺ���ѷ</a>
<a href = listtopic.php>���Ӥѭ</a>
</font>
</center>
</body>
</html>