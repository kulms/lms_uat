<html>
<head>
<title>Student List</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>

<body bgcolor="#99FFFF">
<font face="MS San Sarif">
<center><img src = kaset_small.jpg><img src = "nisit.jpg"></center>
<br>
<center><img src = newline.jpg></center>
<br>
<?
  require("../sql_password.php");
  $link = mysql_connect($server,$sql_username,$sql_password);
  $select = mysql_select_db("ieprojectdatabase",$link);
  $query = "select * from users where category=\"3\" ";
  $result = mysql_query($query,$link);
  print 
  ("
    <table width=\"50%\" border=\"1\" align = center>
    <tr>
      <td><p align=center>�ӴѺ</p></td>
      <td><p align=center>���ʻ�Шӵ�ǹ��Ե</p></td>
      <td><p align=center>����-���ʡ��</p></td>
    </tr>
  ");
  $count=0;
  while ($row = mysql_fetch_row($result))
  {
  $count=$count+1;
    print 
    ("
      <tr>
        <td><p align=center>$count</p></td>
        <td><p align=center><a href=search.php?student_id=$row[0]&list=student>$row[17]</a></p></td>
        <td>$row[16] $row[4] $row[5]</td>
      </tr>
    ");
  }  
  print ("</table>");
?>

</font>
<br>
<center><img src = line.jpg></center>
<br>
<center><font size = 0 color = orange face="MS San Sarif"><a href = list.html>���ҵ��</a></font></center>
<center>
<font color = orange size = 0 face="MS San Sarif">
<a href = listproject.php>�����ç�ҹ</a>
<a href = liststudent.php>���͹ѡ�֡��</a>
<a href = listadviser.php>�����Ҩ����</a>
<a href = listsubject.php>�����Ԫ�</a>
<a href = listcompany.php>���ͺ���ѷ</a>
<a href = listtopic.php>���Ӥѭ</a>
</font>
</center>
</body>
</html>