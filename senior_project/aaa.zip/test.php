html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<form name="form1">
  <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
    <option selected>unnamed1</option>
  </select>
</form>
<form name="form2">
  <select name="menu2" onChange="MM_jumpMenu('parent',this,0)">
    <option value="add/addtopic.php" selected>addtopic</option>
  </select>
</form>
<form name="form3" >
  <select name="select">
    <option>fsdfsdf</option>
  </select>
</form>
<p>&nbsp;</p>
</body>
</html>
