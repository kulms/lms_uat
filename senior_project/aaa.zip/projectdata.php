<html>
<head>
<title>Projectdata</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>

<body bgcolor="#99FFFF">
<font face="MS San Sarif"> 

<?
  require("sql_password.php");
  $link = mysql_connect($server,$sql_username,$sql_password);
  $select = mysql_select_db("ieprojectdatabase",$link);
?>



<center><img src = kaset_small.jpg><img src = "detail.jpg"><img src = kaset_small.jpg></center>
<center><img src = newline.jpg></center>
<br>

<form ENCTYPE="multipart/form-data" action="companydata.php" method="post">
  <p><b>�����ç�ҹ</b>
    <input type="text" name="p_name">
  </p>

  <p><b>�Ҥ�Ԫ�</b> 
    <select name="p_department">
    <?
      $query = "select * from department";
      $result = mysql_query($query,$link);     
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[2]</option>"); }
    ?>
    </select>
  </p>
  <p><b>���Ӥѭ/Key word </b>
    <select name="p_topic">
    <?
      $query = "select * from topic";
      $result = mysql_query($query,$link);     
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[1]</option>"); }
    ?>
    </select>
    <a href="/project/pon/add/addtopic.php">�������Ӥѭ</a>
  </p>
  <p><b>�����ç�ҹ/����ѷ�������Ǣ�ͧ </b>
    <select name="p_company">
    <?
      $query = "select * from company";
      $result = mysql_query($query,$link);
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[1]</option>"); }
    ?>
    </select>
    <a href="/project/pon//add/addcompany.php">���������ç�ҹ<a>
  </p>
  <p><b>�ա���֡�� </b>
    <select name="p_year">
    <?
      $year=2531;
      for ($year=2531;$year<2600;$year++)
      { print ("<option value=$year>$year</option>"); }
    ?>
    </select>
    <b>�Ҥ����֡��</b> 
    <input type="radio" name="p_term" value="��">
    �� 
    <input type="radio" name="p_term" value="����">
    ����
  </p>
  <p><b>�Ԫҷ������Ǣ�ͧ(�ҡ����ش)</b>
    <select name="p_subject">
    <?
      $query = "select * from subject";
      $result = mysql_query($query,$link);
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[1]&nbsp;&nbsp;$row[2]</option>"); }
    ?>
    </select>
<!--    <a href="/projectpon/add/addsubject.php">���������Ԫ�<a>-->
  </p>
  <p><b>�Ԫҷ������Ǣ�ͧ(��� �)</b>
    <select name="p_subject2">
    <?
      $result = mysql_query($query,$link);
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[1]&nbsp;&nbsp;$row[2]</option>"); }
    ?>
    </select>
  </p>
  <p><b>�Ԫҷ������Ǣ�ͧ(��� �)</b>
    <select name="p_subject3">
    <?
      $result = mysql_query($query,$link);
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[1]&nbsp;&nbsp;$row[2]</option>"); }
    ?>
    </select>
  </p>
  <p><b>�Ҩ�������֡���ç�ҹ </b>
    <select name="p_adviser">
    <?
      $query = "select * from users where category=\"2\" ";
      $result = mysql_query($query,$link);
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[17]&nbsp;&nbsp;$row[16]$row[4]&nbsp;&nbsp;$row[5]</option>"); }
    ?>
    </select>
<!--    <a href="addadviser.php">���������Ҩ����<a>-->
  </p>
  <p><b>���͡��캷�Ѵ���(.txt)</b>
    <!--<INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="1024000">-->
    <INPUT NAME="UploadedFile" TYPE="file">
  </p>
  <p><b>�����˵�</b>
    <input type="text" name="p_note">
  </p>

  <p align="right">
    <input type="submit" name="Submit" value="Next">
  </p>
</form> 
</font>
</body>
</html>