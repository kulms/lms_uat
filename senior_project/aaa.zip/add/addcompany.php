<html>
<head>
<title>Add Topic</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>

<body bgcolor="#99FFFF">
<font face="MS San Sarif"> 
<center><img src = kaset_small.jpg><img src = company.jpg><img src = kaset_small.jpg></center>
<center><img src = newline.jpg></center>
<br>
<?
  require("../sql_password.php");
  $link = mysql_connect($server,$sql_username,$sql_password);
  $select = mysql_select_db("ieprojectdatabase",$link);
  $query = "select comname from company";
  $result = mysql_query($query,$link);     
?>

<form action="submit.php">
  <p><b>�����ç�ҹ�������������</b></p>
  <p>
    <select name="companylist" size="5">
    <?
      while ($row = mysql_fetch_row($result))
      { print ("<option value=\"$row[0]\">$row[0]</option>"); }
    ?>
    </select>
  </p>
<br><br>
  <p><b>�������ѭ�ҷ���ͧ���������� : </b>
    <input type="text" name="addcompany">
    <input type="submit" name="Submit" value="Next">
  </p>
</form> 
<a href = "../projectdata.php"><img src = add.jpg border = 0 align = right></a>
</body>
</font>
</html>